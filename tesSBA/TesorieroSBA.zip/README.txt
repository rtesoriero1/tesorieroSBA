Author: Robert Tesoriero
Date: 2/1/23

The purpose of this website is to provide an overview of the children's show Bear in the Big Blue House. 

Accessing it requires a browser that supports both HTML and Javascript.

To run the program, please download the program files from the repo and then locate the AboutPage.html in order to gain full access to the site. 


Information gleamed from: https://en.wikipedia.org/wiki/Bear_in_the_Big_Blue_House
Credit to Bootstrap for the NavBar. 